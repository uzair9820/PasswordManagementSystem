from django.apps import AppConfig


class PasswordmanagerConfig(AppConfig):
    name = 'PasswordManager'
